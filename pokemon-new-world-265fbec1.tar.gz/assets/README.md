# Pokemon: The New World v20.1

A Pokemon-style battle game made with Python and pygame.

## Play online

Once GitHub Pages is switched on (see below), the game is at:

https://joeysongoey.github.io/pokemon-new-world/

Click the page once to start it.

## Play on your computer

```
pip install pygame
python main.py
```

## Controls

- Mouse: click the buttons
- B: start a battle (main menu)
- A: open attacks (in battle)
- 1 to 4: choose an attack
- Esc: go back

## Healing

Click HEAL on the main menu to restore every Pokemon on your team to full HP
(fainted ones are revived). It is free and saves automatically.

## Saving

Use SAVE and LOAD on the main menu. On your computer the save goes to
`pokemon_save.json` next to the game. Online it is stored in your browser,
so it stays on that browser and device.

To move a save between your computer and the browser, press EXPORT CODE and
then IMPORT CODE on the other one. Online, the code is shown in a box to copy
and paste. On a computer, it goes in `pokemon_save_code.txt` next to the game.

## How the online version works

Every time you push to the `main` branch, the GitHub Action in
`.github/workflows/deploy.yml` uses [pygbag](https://pypi.org/project/pygbag/)
to turn `main.py` into a web version and publish it to the `gh-pages` branch.

## What's new in v13.0

- **XP and levels:** your active Pokemon earns XP for every win. Each level
  gives +8 max HP and +2 attack power.
- **Coins and the Poke Mart:** win battles to earn coins, then press SHOP on
  the main menu to buy Poke Balls (20), Great Balls (50) and Ultra Balls (100).
- **Battle Tournament:** beat 4 trainers and Champion Vex in a row to win a
  trophy and coins. Your team recovers half its HP between rounds. No
  catching, no healing, and RUN becomes FORFEIT.
- **New sprites:** every wild Pokemon now has its own body shape (cats, fish,
  dragons, birds, golems, ghosts, bugs, plants, imps and star-orbs), and first
  forms are smaller than final forms.

## What's new in v20.1

- Music now starts **muted**. Tap the speaker in the top-right corner to turn
  it on, and the game remembers your choice.

## What's new in v20.0

- **After you finish Story Mode, Ember Cave changes:**
  - Eusine appears and walks with you.
  - Eusine lends you **Warternut** (#634, Water, Lv 65). It goes back to Eusine
    when you leave the cave.
  - The sealed door opens into **Moltenion's Lair**.
  - Press A at the fire altar to battle **Moltenion** (#633, Fire/Dragon,
    Lv 75), and catch it!

## What's new in v19.9

- **New leafy tall grass** in every explore area, with colours that match each region.
- **New buildings:**
  - Hometown: a stone HEAL centre, a timber SHOP and a straw-roof cottage.
  - Timber heal houses in every region, with a snowy roof in Sinnoh.
  - New beach buildings at Coral Beach.
  - A mossy forest shrine, a stone windmill and a castle with towers.

## What's new in v19.8

- **Simple menu:** five big buttons, EXPLORE, BATTLE, POKEMON, BAG & SHOP and
  FLY, plus OPTIONS. Each opens a small pop-up with the options grouped inside.
- **Auto-save:** the game saves by itself after important things, such as
  catching a Pokemon, winning a tournament or Elite Cup, beating a boss, story
  chapters, event codes, evolving, training and prestige ranks. A "Game saved"
  note pops up. It never saves in the middle of a battle or tournament.
- **Auto-load:** your save loads by itself when you open the game.
- **Manual save:** still in OPTIONS > Save Now.

## What's new in v19.7

- **Ninja Trials:** battle the Sun Monk and the Moon Monk at the pagoda. They
  start at Lv 45 and get 5 levels stronger every time. Each win gives +1
  prestige and 500 coins.
- **Ninja points:** every battle won by a Sun or Moon Path Pokemon earns a
  point, and 10 points give +1 prestige.
- **New ranks:**
  - Rank 10, Shadow Shogun: Blazing Shuriken and Phantom Shuriken TMs.
  - Rank 15, Eclipse Sensei: Eclipshin (#632).
  - Rank 20, Legendary Ninja: Total Eclipse TM.

## What's new in v19.6

- **Pagoda Training** (Johto, Lantern Hollow): pick a Pokemon and pay 7000 coins
  to walk a path. Training masters all of its moves, and the path is forever.
  - **Sun Path:** the Pokemon can use Sun Avatar.
  - **Moon Path:** the Pokemon gets Super Sonic, which hits 3-5 times for
    30-100 damage each, once per battle.
- **Ninja Prestige:** every training raises your rank.
  - Rank 1: Shadow Step and Dawn Strike TMs.
  - Rank 2: Solshin (#630).
  - Rank 3: Sunfire Kunai and Moonshadow Kunai TMs, plus Lunashin (#631).
  - Rank 5: Eclipse Edge TM and the Grandmaster title.
- **TM Case:** teach TM moves. The new move replaces the Pokemon's weakest move.

## What's new in v19.5

- **An explore area in every region:** fly to a region and tap EXPLORE.
  - Kanto: Sunflower Fields, with a windmill.
  - Johto: Lantern Hollow, with a lantern tower.
  - Hoenn: Ashfall Dunes, with a volcano.
  - Sinnoh: Frostpeak Pass, with an ice spire.
  - Unova: Voltage City, with a power plant.
  - Kalos: Bloom Gardens, with a palace.
  - Alola: Palm Lagoon, with a tiki hut.
  - Galar: Stonemoor Ruins, with a castle.
  - Paldea: Starfall Crater, with a fallen star.

  Each area has a heal house, and its wild Pokemon match the region's types.
- **Harbour Inn** (west end of the Coral Beach boardwalk): pay 1000 coins for a
  comfy massage that heals your team and gives it +100 HP for 3 battles.
- **SURF shop:** Kai the surfer gives hints and a free gift once a day. He sells
  Wave Balls (great for Water Pokemon), a Fishing Rod, a Tide Charm (Water moves
  +20%) and a Surfboard.
- **Fishing:** with the Fishing Rod, press A at the end of the pier.
- **Hidden Isle:** with the Surfboard, press A at the surfboard on the sand to
  surf to a secret island with ancient ruins and rare Pokemon.
- **Slimmer, more detailed trainer sprite.**

## What's new in v19.4

- **New trainer:** the explore trainer is now the orange-headband hero, with a
  green jacket and brown bag, walking in all four directions.

## What's new in v19.3

- **Inside the Sungolia Temple:** walk through the temple doors into a golden
  hall with pillars, pools, fire braziers and a sun altar. The altar opens Story
  Mode once Xrencha is unlocked.
- **Whisperwood Forest** (north of Hometown): a dark forest with an old shrine.
  Grass, Bug, Ghost and Poison Pokemon live here.
- **Coral Beach** (south of Hometown): palm trees, a SURF shop, a lighthouse and
  a pier. Water, Flying and Ice Pokemon hide in the dune grass.
- **Ember Cave** (east end of the beach boardwalk): lava pools, glowing crystals
  and a sealed door. Fire, Rock, Ground and Dragon Pokemon live here.

## What's new in v19.2

- **New battle layout:** a retro message box ("What will Flame do?") and four big
  buttons, Attack, Switch, Bag and Run. Bag holds Poke Balls and Items.
- **Smoother music:** all tracks remade without the buzzy and crackly sounds.

## What's new in v19.1

- **Music:** 5 original chiptune tracks (in `music/`). There's a title theme, a
  town and exploring theme, a wild battle theme, a legendary battle theme (for
  legendaries, bosses, the Trial of the Deep and story battles) and a victory jingle.
- **Mute button** in the top-right corner of every screen. The setting is saved
  with your game.

## What's new in v19.0

- **EXPLORE:** walk around a retro world as your own trainer. Use the on-screen
  D-pad, or arrow keys and WASD. A (Space or Enter) talks or uses things, and
  B (X) closes messages.
- **Hometown:** walk into HEAL to heal your team and SHOP to buy things. Read the
  signpost.
- **Tall grass:** wild Pokemon jump out as you walk, and battles use the normal
  battle screen. After the battle you're back where you were.
- **Route to the Sungolia Temple:** the road east of town leads to the temple. If
  you've unlocked Xrencha, its doors open Story Mode.

## What's new in v18.9

- **The full Story Mode, 14 chapters,** played from the STORY MODE button in Xrencha:
  hunt Genesis Lab, uncover Project Origin, learn ???'s true name (Xlovon), revive
  Rustarion, catch Nuxillon, and stop Dr. Vexa's created legendary, Genexion.
- Every chapter gives 300 coins.
- **Final prize:** Genexion joins your team at Lv 100, as strong as the Trial of the
  Deep Aetherion. You also get the "Hero of Xrencha" title for your team, a Story
  Trophy, 5000 coins and 10 XL Poke Balls.
- New story Pokemon: Sentrix (#626), Solguard (#627), Rustarion (#628) and
  Genexion (#629).
- Pokemon you have to catch in the story always hang on with 1 HP.

## What's new in v18.8

- **Story Mode Chapter 2: The Rusted Secret.** ??? won't go to the museum, the
  fossil starts to glow, and scientists show up wanting the fossil. Beat the
  Scientist (3 Pokemon, Lv 45) and a stronger Nuxillon (Lv 50).
- The mech from Chapter 1 now keeps its secret name, ???, everywhere, including
  the Pokedex, until the story reveals it.

## What's new in v18.7

- **STORY MODE** in Xrencha. Chapter 1, The Sungolia Temple: explore the temple
  with Eusine, fight off the pesky Nuxillon (it dodges every Poke Ball), then catch
  the unknown mech Pokemon with 5 XL Poke Balls.
- New story Pokemon: Nuxillon (Dark/Dragon, #624) and Xlovon (Steel/Electric, #625).
  Neither appears in the wild.
- XL Poke Balls: the strongest ball, story only.
- Story progress is saved, and lost story battles can be retried.

## What's new in v18.6

- **Xrencha menu:** in Xrencha the main menu only has BATTLE, TRIAL OF THE DEEP
  and FLY. Fly to another region to heal, shop and save.
- **Trial of the Deep:** fight Aetherion and Varkrion together at Lv 100. Your team
  is healed first, and they can't be caught. Win to get both as Lv 70 Pokemon plus
  1000 coins (first win only). You'll need a team around Lv 80.
- Aetherion and Varkrion no longer appear in the wild or in the Mysterious
  Dimension. The trial is the only way to get them.

## What's new in v18.5

- **Xrencha:** a secret new place on the FLY screen, unlocked with a secret event
  code (EVENT CODE button). It has 75 Pokemon that live nowhere else (#547 to #621).
- **Two Origin legendaries,** found only in Xrencha: Solvarion, the Celestial Origin
  (Light/Cosmic, #622), and Nulvexion, the Void Origin (Void/Glitch, #623). They can
  also appear together in a Duo Legendary Battle.
- **20 new types:** Crystal, Moon, Wind, Thunder, Rune, Magma, Earth, Eclipse, Dream,
  Swamp, Shadow, Nature, Gravity, Metal, Sound, Plasma, Stone, Blood, Beast and Time,
  each with its own colour, moves and level-up moves. They take normal damage from
  every type for now.
- The Pokedex now has 623 Pokemon.

## What's new in v18.4

- Eclipsar has a new eclipse dragon sprite.
- Aura Brawler has a new armoured sprite with blue aura fists.
- NYSTRIA and Eclipsar have new galaxy dragon sprites.

- **High quality sprites:** every drawn Pokemon is now drawn at 3x size and
  shrunk, so edges are smooth and sharp instead of blurry.
- Picture sprites get soft shading too.
- Flame and NYSTRIA keep their original look.

## What's new in v18.3

- **More detailed sprites:** every drawn Pokemon now has shading, a light edge,
  a crisp outline and its own markings (spots, stripes, speckles or bands).
  Flame, NYSTRIA and the picture sprites are unchanged.

## What's new in v18.2

- New sprites for Embercub, Blazepaw, Pyroclaw, Voltkit, Frostbit, Glacieron,
  Cryowraith, Aquaffin, Abyssurge, Mechling and Rockruffle.

- Aetherion has a new crystal dragon sprite, and Varkrion has a new shadow dragon sprite.

- **100 more Pokemon, #447 to #546**, bringing the Pokedex to 546.
- The new Lumidrake was renamed Radiadrake, since Lumidrake is already #59.
- New Glitch-type moves: Data Rush, Byte Crash and Bit Flip.
- Void now has a Type Master challenge (20 challenges in all).

## What's new in v18.1

- **100 new Pokemon, #347 to #446**, bringing the Pokedex to 446. HP and attack
  come from the stats list. The game doesn't use DEF and SPD yet.
- Names already in the game were renamed: Snowhopper, Sparktusk, Lavaclaw,
  Puffloon, Reeflisk, Psydrake, Cindermole, Thornlisk, Mindpixie, Blazelisk,
  Bramblox, Frostowl, Nimbudrake, Rimefang and Shadebramble.
- Light now has a Type Master challenge.
- Fixed: single-type Pokemon from v16.1 no longer have the same move twice.

## What's new in v18.0

- **Bond system:** Pokemon gain bond for every battle they win. Every 20 points
  is a heart (shown on the team screen) with its own line of dialogue. At 3 hearts
  a Pokemon can hang on with 1 HP. At 5 hearts it learns its own Bond Strike move.
- **Titles:** Pokemon earn titles like Void Hunter (beat 10 Void Pokemon),
  Flame Champion (Fire Type Master), Glitch Survivor (win under 10% HP),
  Boss Breaker, Champion and Best Friend. The title shows next to their name.
  Tap TITLE on the team screen to change it.
- **Move Mastery:** using a move 20 times masters it, adding +10 power, a gold
  star and a gold sparkle when it hits.
- **CHALLENGES** button on the menu:
  - **Type Masters:** beat 3 trainers of one type (18 types) for coins, a badge,
    a title and a SHINY Pokemon of that type.
  - **Boss Rematches:** fight bosses you've beaten again. They get stronger
    every time, with bonus coins for winning.
- **Secret Areas** on the FLY screen: Hidden Cave (win 15 battles), Abandoned Lab
  (catch 25 kinds) and Mysterious Dimension (win the Battle Tournament). Each has
  its own wild Pokemon.
- **Legendary encounters:** each secret area has its own legendary, with a
  special introduction screen. The Lab and the Dimension have a riddle to solve first.
- **Duo Legendary Battles:** in the Mysterious Dimension, Aetherion and Varkrion
  can appear together. Beat or catch one and the other takes its power.

## What's new in v17.2

- **EVENT CODE button** with an on-screen keyboard, so event codes work on
  iPads and phones that block pop-up boxes. A real keyboard works too.

## What's new in v17.1

- **Aura Brawler (#346), an event-only Pokemon.** It never appears in battles or
  tournaments. Enter the secret code with the EVENT CODE button to get it. Your save stays
  as it is, and a save code exported afterwards keeps Aura Brawler.

## What's new in v17.0

- **New moves by level:** every Pokemon learns a stronger move at Lv 15, 25, 35, 50 and 70.
  Dual types take turns between their two types.
- With four moves already, the new move replaces the weakest one.
- 110 new moves, with power from 45 at Lv 15 up to 80 at Lv 70.
- The team screen shows the level of the next new move.
- Game files now get a new name on every update, so browsers load the latest version.

## What's new in v16.2

- The starting team now uses new original pixel-art creatures for Lucario, Luxray, Suicune, Gyarados, Morpeko, Dialga and both MissingNo. (Flame is unchanged).

- **Omni-Dex sprites:** 21 sprites cut from the Omni-Dex screenshot now appear in the game
  for Embercub, Blazepaw, Pyroclaw, Frostbit, Glacieron, Cryowraith, Leaflet, Thornox,
  Floragon, Mechling, Ironclast, Titanforge, Rockruffle, Cragoyle, Terradon, Starlingo,
  Galaxion, Lumidrake, Shadelet, Hauntalon and Dreadgeist. The pictures are in `sprites/`.

## What's new in v16.1

- **200 new Pokemon, #146 to #345**, bringing the Pokedex to 345. Every one has
  a type, stats, four moves and a Pokedex entry. Their entries and moves are
  short placeholders you can rewrite.
- Stats for #246 to #345 come from the stats file. Stats for #146 to #245 are
  placeholder values.
- Duplicate names were renamed: Tidewyrm, Frostmaw, Cragwing, Gravewing,
  Toxmite, Glacyowl, Bloomisk, Sporemantis, Stormrake, Mossox, Seismotusk,
  Magmaut and Scorchclaw.

## What's new in v16.0

- **Evolution:** Pokemon #1 to #45 come in families of three. Stage 1 evolves
  at Lv 16 and stage 2 at Lv 32, getting more HP, power and new moves.
- **Regions and FLY:** fly between 10 regions. Each one has its own colours
  and its own common Pokemon types.
- **Battle items:** buy Potions, Super Potions and Revives in the shop, then
  press ITEMS in battle. Using one takes your turn. You start with 3 Potions.
- **Shiny Pokemon:** a 1 in 200 chance of a different colour, marked with a
  gold star. Caught shinies get a star in the Pokedex.
- **Elite Cup:** a harder second tournament with five Lv 40 to 62 trainers.
  It unlocks after you win the Battle Tournament.
- **Eclipsar returns** from v10.1 as Mythical Pokemon #145 (0.3% per battle).
- **Types shown in battle** as coloured labels, and attack buttons are
  coloured by type with a x2 or x0.5 hint.
- **Smarter enemies** that usually pick their most effective move.
- **TYPE CHART** screen on the main menu and in the Pokedex.
- **Pokedex entries** for all of the original 66 Pokemon.
- **Export and import save codes.**
- NYSTRIA stays at a 5% chance per battle.

## What's new in v15.0

- **Type effectiveness** in every battle, for your attacks and the enemy's.
  - Super effective moves do 2x damage, and 4x when both of the defender's types are weak.
  - Not very effective moves do 0.5x, and some matchups have no effect at all.
  - Battle messages show SUPER EFFECTIVE!, Not very effective... or It had no effect!
- Uses the standard 18-type chart, with Ice kept super effective against Fire.

## What's new in v14.0

- **76 new Pokemon** (numbers 67 to 142), each with its own sprite, HP, attack
  bonus, four attacks and Pokedex entry. Numbers 133 to 142 are legendary and
  mythical.
- **Rare encounters:** legendary Pokemon appear in about 1 in 500 battles each,
  and mythical ones in about 1 in 1000. Catching them is harder.
- **POKEDEX** button on the main menu: shows how many Pokemon you have caught
  and seen, lets you read entries, and is saved with your game.

- **Legendary duo:** Aetherion (Dragon/Psychic, #143) and Varkrion (Dark/Steel, #144), with their own sprites and very rare encounters.
