# Pokemon: The New World v16.1

A Pokemon-style battle game made with Python and pygame.

## Play online

Once GitHub Pages is switched on (see below), the game is at:

https://joeysongoey.github.io/pokemon-new-world/

Click the page once to start it.

## Play on your computer

```
pip install pygame
python main.py
```

## Controls

- Mouse: click the buttons
- B: start a battle (main menu)
- A: open attacks (in battle)
- 1 to 4: choose an attack
- Esc: go back

## Healing

Click HEAL on the main menu to restore every Pokemon on your team to full HP
(fainted ones are revived). It is free and saves automatically.

## Saving

Use SAVE and LOAD on the main menu. On your computer the save goes to
`pokemon_save.json` next to the game. Online it is stored in your browser,
so it stays on that browser and device.

To move a save between your computer and the browser, press EXPORT CODE and
then IMPORT CODE on the other one. Online, the code is shown in a box to copy
and paste. On a computer, it goes in `pokemon_save_code.txt` next to the game.

## How the online version works

Every time you push to the `main` branch, the GitHub Action in
`.github/workflows/deploy.yml` uses [pygbag](https://pypi.org/project/pygbag/)
to turn `main.py` into a web version and publish it to the `gh-pages` branch.

## What's new in v13.0

- **XP and levels:** your active Pokemon earns XP for every win. Each level
  gives +8 max HP and +2 attack power.
- **Coins and the Poke Mart:** win battles to earn coins, then press SHOP on
  the main menu to buy Poke Balls (20), Great Balls (50) and Ultra Balls (100).
- **Battle Tournament:** beat 4 trainers and Champion Vex in a row to win a
  trophy and coins. Your team recovers half its HP between rounds. No
  catching, no healing, and RUN becomes FORFEIT.
- **New sprites:** every wild Pokemon now has its own body shape (cats, fish,
  dragons, birds, golems, ghosts, bugs, plants, imps and star-orbs), and first
  forms are smaller than final forms.

## What's new in v16.2

- The team's Lucario and Luxray now use new original pixel-art creatures, not copies of their official designs.

- **Omni-Dex sprites:** 21 sprites cut from the Omni-Dex screenshot now appear in the game
  for Embercub, Blazepaw, Pyroclaw, Frostbit, Glacieron, Cryowraith, Leaflet, Thornox,
  Floragon, Mechling, Ironclast, Titanforge, Rockruffle, Cragoyle, Terradon, Starlingo,
  Galaxion, Lumidrake, Shadelet, Hauntalon and Dreadgeist. The pictures are in `sprites/`.

## What's new in v16.1

- **200 new Pokemon, #146 to #345**, bringing the Pokedex to 345. Every one has
  a type, stats, four moves and a Pokedex entry. Their entries and moves are
  short placeholders you can rewrite.
- Stats for #246 to #345 come from the stats file. Stats for #146 to #245 are
  placeholder values.
- Duplicate names were renamed: Tidewyrm, Frostmaw, Cragwing, Gravewing,
  Toxmite, Glacyowl, Bloomisk, Sporemantis, Stormrake, Mossox, Seismotusk,
  Magmaut and Scorchclaw.

## What's new in v16.0

- **Evolution:** Pokemon #1 to #45 come in families of three. Stage 1 evolves
  at Lv 16 and stage 2 at Lv 32, getting more HP, power and new moves.
- **Regions and FLY:** fly between 10 regions. Each one has its own colours
  and its own common Pokemon types.
- **Battle items:** buy Potions, Super Potions and Revives in the shop, then
  press ITEMS in battle. Using one takes your turn. You start with 3 Potions.
- **Shiny Pokemon:** a 1 in 200 chance of a different colour, marked with a
  gold star. Caught shinies get a star in the Pokedex.
- **Elite Cup:** a harder second tournament with five Lv 40 to 62 trainers.
  It unlocks after you win the Battle Tournament.
- **Eclipsar returns** from v10.1 as Mythical Pokemon #145 (0.3% per battle).
- **Types shown in battle** as coloured labels, and attack buttons are
  coloured by type with a x2 or x0.5 hint.
- **Smarter enemies** that usually pick their most effective move.
- **TYPE CHART** screen on the main menu and in the Pokedex.
- **Pokedex entries** for all of the original 66 Pokemon.
- **Export and import save codes.**
- NYSTRIA stays at a 5% chance per battle.

## What's new in v15.0

- **Type effectiveness** in every battle, for your attacks and the enemy's.
  - Super effective moves do 2x damage, and 4x when both of the defender's types are weak.
  - Not very effective moves do 0.5x, and some matchups have no effect at all.
  - Battle messages show SUPER EFFECTIVE!, Not very effective... or It had no effect!
- Uses the standard 18-type chart, with Ice kept super effective against Fire.

## What's new in v14.0

- **76 new Pokemon** (numbers 67 to 142), each with its own sprite, HP, attack
  bonus, four attacks and Pokedex entry. Numbers 133 to 142 are legendary and
  mythical.
- **Rare encounters:** legendary Pokemon appear in about 1 in 500 battles each,
  and mythical ones in about 1 in 1000. Catching them is harder.
- **POKEDEX** button on the main menu: shows how many Pokemon you have caught
  and seen, lets you read entries, and is saved with your game.

- **Legendary duo:** Aetherion (Dragon/Psychic, #143) and Varkrion (Dark/Steel, #144), with their own sprites and very rare encounters.
